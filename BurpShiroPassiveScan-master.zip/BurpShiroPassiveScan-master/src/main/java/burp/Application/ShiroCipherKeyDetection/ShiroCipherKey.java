package burp.Application.ShiroCipherKeyDetection;

import burp.Application.ShiroFingerprintDetection.ShiroFingerprint;
import burp.Application.ShiroCipherKeyDetection.ExtensionMethod.*;

import burp.IBurpExtenderCallbacks;
import burp.IHttpRequestResponse;

import burp.Bootstrap.Encrypt.*;

import java.util.Date;

public class ShiroCipherKey {

    private ShiroCipherKeyMethodInterface shiroCipherKeyMethod;

    // 该模块启动日期
    private Date startDate = new Date();

    // 程序最大执行时间,单位为秒
    // 会根据payload的添加而添加
    private int maxExecutionTime = 120;

    public ShiroCipherKey(IBurpExtenderCallbacks callbacks,
                          IHttpRequestResponse baseRequestResponse,
                          ShiroFingerprint shiroFingerprint,
                          String callClassName) {
        this.init(callbacks, baseRequestResponse, shiroFingerprint, callClassName);
    }

    private ShiroCipherKeyMethodInterface init(IBurpExtenderCallbacks callbacks,
                                               IHttpRequestResponse baseRequestResponse,
                                               ShiroFingerprint shiroFingerprint,
                                               String callClassName) {

        String[] keys = {
"0Av6jWaXCkCu5A9nJbPxLI==",
"0AvVhmFLUs0KTA3Kprsdag==",
"1AvVhdsgUs0FSA3SDFAdag==",
"1QWLxg+NYmxraMoxAXu/Iw==",
"1tC/xrDYs8ey+sa3emtiYw==",
"25BsmdYwjnfcWmnhAciDDg==",
"2A2V+RFLUs+eTA3Kpr+dag==",
"2AvVhdsgUs0FSA3SDFAdag==",
"2cVtiE83c4lIrELJwKGJUw==",
"2itfW92XazYRi5ltW0M2yA==",
"3AvVhdAgUs0FSA4SDFAdBg==",
"3AvVhmFLUs0KTA3Kprsdag==",
"3JvYhmBLUs0ETA5Kprsdag==",
"3qDVdLawoIr1xFd6ietnwg==",
"4AvVhdsgUs0F563SDFAdag==",
"4AvVhmFLUs0KTA3Kprsdag==",
"4BvVhmFLUs0KTA3Kprsdag==",
"5aaC5qKm5oqA5pyvAAAAAA==",
"5AvVhmFLUS0ATA4Kprsdag==",
"5AvVhmFLUs0KTA3Kprsdag==",
"5J7bIJIV0LQSN3c9LPitBQ==",
"5RC7uBZLkByfFfJm22q/Zw==",
"66v1O8keKNV3TTcGPK1wzg==",
"6AvVhmFLUs0KTA3Kprsdag==",
"6NfXkC7YVCV5DASIrEm1Rg==",
"6Zm+6I2j5Y+R5aS+5ZOlAA==",
"6ZmI6I2j3Y+R1aSn5BOlAA==",
"6ZmI6I2j5Y+R5aSn5ZOlAA==",
"7AvVhmFLUs0KTA3Kprsdag==",
"8AvVhmFLUs0KTA3Kprsdag==",
"8BvVhmFLUs0KTA3Kprsdag==",
"9AvVhmFLUs0KTA3Kprsdag==",
"9FvVhtFLUs0KnA3Kprsdyg==",
"a2VlcE9uR29pbmdBbmRGaQ==",
"a3dvbmcAAAAAAAAAAAAAAA==",
"A7UzJgh1+EWj5oBFi+mSgw==",
"aU1pcmFjbGVpTWlyYWNsZQ==",
"Bf7MfkNR0axGGptozrebag==",
"bTBANVpaOUw0ampRWG43TVJFcF5iXjdJ",
"bWljcm9zAAAAAAAAAAAAAA==",
"bWluZS1hc3NldC1rZXk6QQ==",
"bXdrXl9eNjY2KjA3Z2otPQ==",
"bXRvbnMAAAAAAAAAAAAAAA==",
"bya2HkYo57u6fWh5theAWw==",
"c+3hFGPjbgzGdrC+MHgoRQ==",
"c2hpcm9fYmF0aXMzMgAAAA==",
"cGhyYWNrY3RmREUhfiMkZA==",
"cGljYXMAAAAAAAAAAAAAAA==",
"ClLk69oNcA3m+s0jIMIkpg==",
"cmVtZW1iZXJNZQAAAAAAAA==",
"CrownKey==a12d/dakdad",
"d2ViUmVtZW1iZXJNZUtleQ==",
"empodDEyMwAAAAAAAAAAAA==",
"ertVhmFLUs0KTA3Kprsdag==",
"eXNmAAAAAAAAAAAAAAAAAA==",
"f/SY5TIve5WWzT4aQlABJA==",
"fCq+/xW488hMTCD+cmJ3aQ==",
"fdCEiK9YvLC668sS43CJ6A==",
"FJoQCiz0z5XWz2N2LyxNww==",
"FL9HL9Yu5bVUJ0PDU1ySvg==",
"FP7qKJzdJOGkzoQzo2wTmA==",
"fPimdozRt+SSSbZS8/HARA==",
"fsHspZw/92PrS3XrPW+vxw==",
"GAevYnznvgNCURavBhCr1w==",
"GsHaWo4m1eNbE0kNSMULhg==",
"hBlzKg78ajaZuTE0VLzDDg==",
"HeUZ/LvgkO7nsa18ZyVxWQ==",
"HoTP07fJPKIRLOWoVXmv+Q==",
"HWrBltGvEZc14h9VpMvZWw==",
"i45FVt72K2kLgvFrJtoZRw==",
"iALQtn3PfIXe74CT/wrS7g==",
"IduElDUpDDXE677ZkhhKnQ==",
"ikB3y6O9BpimrZLB3rca0w==",
"Is9zJ3pzNh2cgTHB4ua3+Q==",
"iycgIIyCatQofd0XXxbzEg==",
"Jt3C93kMR9D5e8QzwfsiMw==",
"k3+XHEg6D8tb2mGm7VJ3nQ==",
"kPH+bIxk5D2deZiIxcaaaA==",
"kPH+bIxk5D2deZiIxcabaA==",
"kPH+bIxk5D2deZiIxcacaA==",
"kPv59vyqzj00x11LXJZTjJ2UHW48jzHN",
"KU471rVNQ6k7PQL4SqxgJg==",
"L7RioUULEFhRyxM7a2R/Yg==",
"l8cc6d2xpkT1yFtLIcLHCg==",
"LEGEND-CAMPUS-CIPHERKEY==",
"lT2UvDUmQwewm6mMoiw4Ig==",
"m0/5ZZ9L4jjQXn7MREr/bw==",
"MDgBSEFqYIoWYezkWDywig==",
"MPdCMZ9urzEA50JDlDYYDg==",
"MTIzNDU2Nzg5MGFiY2RlZg==",
"MTIzNDU2NzgxMjM0NTY3OA==",
"MzVeSkYyWTI2OFVLZjRzZg==",
"NGk/3cQ6F5/UNPRh8LpMIg==",
"nhNhwZ6X7xzgXnnZBxWFQLwCGQtJojL3",
"NoIw91X9GSiCrLCF03ZGZw==",
"NsZXjXVklWPZwOfkvk6kUA==",
"O4pdf+7e+mZe8NyxMTPJmQ==",
"oPH+bIxk5E2enZiIxcqaaA==",
"OUHYQzxQ/W9e/UjiAGu6rg==",
"OY//C4rhfwNxCQAQCrQQ1Q==",
"Q01TX0JGTFlLRVlfMjAxOQ==",
"QAk0rp8sG0uJC4Ke2baYNA==",
"r0e3c16IdVkouZgk1TKVMg==",
"Rb5RN+LofDWJlzWAwsXzxg==",
"rPNqM6uKFCyaL10AK51UkQ==",
"RVZBTk5JR0hUTFlfV0FPVQ==",
"s0KTA3mFLUprK4AvVhsdag==",
"s2SE9y32PvLeYo+VGFpcKA==",
"SDKOLKn2J1j/2BHjeZwAoQ==",
"sHdIjUN6tzhl8xZMG3ULCQ==",
"SkZpbmFsQmxhZGUAAAAAAA==",
"SrpFBcVD89eTQ2icOD0TMg==",
"tiVV6g3uZBGfgshesAQbjA==",
"U0hGX2d1bnMAAAAAAAAAAA==",
"U3BAbW5nQmxhZGUAAAAAAA==",
"U3ByaW5nQmxhZGUAAAAAAA==",
"UGlzMjAxNiVLeUVlXiEjLw==",
"Us0KvVhTeasAm43KFLAeng==",
"V2hhdCBUaGUgSGVsbAAAAA==",
"vXP33AonIp9bFwGl7aT7rA==",
"WcfHGU25gNnTxTlmJMeSpw==",
"wGiHplamyXlVB11UXWol8g==",
"WkhBTkdYSUFPSEVJX0NBVA==",
"WuB+y2gcHRnY2Lg9+Aqmqg==",
"XgGkgqGqYrix9lI6vxcrRw==",
"XTx6CKLo/SdSgub+OPHSrw==",
"xVmmoltfpb8tTceuT5R7Bw==",
"Y1JxNSPXVwMkyvES/kJGeQ==",
"yeAAo1E8BOeAYfBlm4NG9Q==",
"YI1+nBV//m7ELrIyDHm6DQ==",
"Ymx1ZXdoYWxlAAAAAAAAAA==",
"yNeUgSzL/CfiWw1GALg6Ag==",
"YTM0NZomIzI2OTsmIzM0NTueYQ==",
"YWJjZGRjYmFhYmNkZGNiYQ==",
"Z3h6eWd4enklMjElMjElMjE=",
"Z3VucwAAAAAAAAAAAAAAAA==",
"ZAvph3dsQs0FSL3SDFAdag==",
"zIiHplamyXlVB11UXWol8g==",
"ZjQyMTJiNTJhZGZmYjFjMQ==",
"ZmFsYWRvLnh5ei5zaGlybw==",
"ZnJlc2h6Y24xMjM0NTY3OA==",
"zSyK5Kp6PZAAjlT+eeNMlg==",
"ztLX7sun",
"ZUdsaGJuSmxibVI2ZHc9PQ==",
"ZWvohmPdUsAWT3=KpPqda",
        };

        // 获得最终的程序最大执行时间
        int keyLength = keys.length;
        if (keyLength > 20) {
            this.maxExecutionTime += (keyLength - 20) * 2;
        }

        if (callClassName.equals("ShiroCipherKeyMethod2")) {
            ShiroCipherKeyMethod2 shiroCipherKey = new ShiroCipherKeyMethod2(
                    callbacks,
                    baseRequestResponse,
                    keys,
                    shiroFingerprint,
                    this.startDate,
                    this.maxExecutionTime,
                    new CbcEncrypt());

            if (shiroCipherKey.isShiroCipherKeyExists()) {
                this.shiroCipherKeyMethod = shiroCipherKey;
            } else {
                ShiroCipherKeyMethod2 shiroCipherKey2 = new ShiroCipherKeyMethod2(
                        callbacks,
                        baseRequestResponse,
                        keys,
                        shiroFingerprint,
                        this.startDate,
                        this.maxExecutionTime,
                        new GcmEncrypt());
                this.shiroCipherKeyMethod = shiroCipherKey2;
            }

            return this.shiroCipherKeyMethod;
        }

        throw new IllegalArgumentException(
                String.format("ShiroCipherKey模块-对不起您输入的 %s 扩展找不到", callClassName));
    }

    public ShiroCipherKeyMethodInterface run() {
        return this.shiroCipherKeyMethod;
    }
}
