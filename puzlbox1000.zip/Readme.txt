﻿PuzlBox 1.0.0.0

Copyright (C) 2010 John Leitch john.leitch5@gmail.com

==Description
PuzlBox is a PHP fuzz tool that scans for several different vulnerabilities by
performing dynamic program analysis. It can detect the following vulnerabilities:

Arbitrary Command Execution
Arbitrary PHP Execution
Local File Inclusion
Aribtray File Read/Write/Change/Rename/Delete
SQL Injection
Reflected Cross-site Scripting

==Usage
PuzlBox must be run as administrator!

puzlbox [-s Server (default localhost)] [-m Scan Modes (default CFLPSX)] [Absolute Web Root] [-n No Unhook] [Application Paths (comma delimited)]

Modes:
C - Arbitrary Command Execution
F - Arbitrary File Read/Write/Change/Rename/Delete
L - Local File Inclusion
P - Arbitrary PHP Execution
S - SQL Injection
X - Reflected Cross-site Scripting

Examples:
puzlbox c:\xampp\htdocs MyApp
Runs all scans on MyApp, located in web root c:\xampp\htdocs

puzlbox -m CX c:\xampp\htdocs MyApp1,MyApp2
Runs Arbitrary Command Execution and Reflected Cross-site Scripting scans on MyApp1 
and MyApp2 located in web root c:\xampp\htdocs