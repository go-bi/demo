﻿$(function () {
    var filter = $('[type="checkbox"][name="filter"]');
    var view_data_container = $("#view_data_container");
    var first_tab_click = function () {
        var tab = $('.nav-tabs a[data-toggle="tab"]:first', view_data_container);
        tab.tab('show');
    }
    $("#accordion .panel-body").css({ "max-height": $(window).height() - 390, "overflow": "auto" });
    view_data_container.css({ "max-height": $(window).height() - 120, "overflow": "auto" });
    var display_data_product = function ($obj, result_container) {
        var data = $obj.data("load_detail");
        if (!data || data == undefined || data.length == 0) {
            result_container.html('<div class="well well-sm">没有数据！</div>');
            return;
        }
        result_container.setTemplate('<ul class="list-unstyled">{#foreach $T as record}<li><div class="checkbox"><label><input type="checkbox" data-url="{$T.record.url}" value="{$T.record.id}" />{$T.record.name}</label> <span class="label label-primary getFileDetail" data-loaded="false" data-id="{$T.record.id}">详细信息</span></div></li>{#/for}</ul>');
        result_container.processTemplate(data);
    };
    $(document).on("shown.bs.tab", 'a[data-loadproduct="true"][data-toggle="tab"]', function (e) {
        var $this = $(e.target);
        if ($this.attr('data-loaded') == 'true') {
            return;
        }
        var result_container = $("#lang_" + $this.data("id"), view_data_container);
        result_container.html('<i class="fa fa-spinner fa-spin"></i>');
        if ($this.attr("data-loading") == "true")
            return;
        $this.attr("data-loading", "true");
        var category = $(".category li.active:first");
        $.post("/Category/GetList", { id: category.data("id"), lang: $this.data("id"), filter: filter.prop("checked") }, function (response) {
            if (response.status) {
                $this.data("load_detail", response.result);
                display_data_product($this, result_container);
                $this.attr('data-loaded', 'true');
                $this.attr("data-loading", "false");
            }
        });
    });
    $('#search_form').on("submit", function () {
        var $this = $(this);
        var keyword = $.trim($('[name="keyword"]', $this).val() || "");
        if (keyword == "") {
            alert("搜索关键字不能为空");
            return false;
        }
        if ($this.attr("data-loading") == "true")
            return false;
        view_data_container.html('<i class="fa fa-spinner fa-spin"></i>');
        $this.attr("data-loading", "true");
        $.post('/Category/Search', { keyword: keyword, filter: filter.prop("checked") }, function (response) {
            if (response.status) {
                var data = response.result;
                if (!data || data == undefined || data.length == 0) {
                    view_data_container.html('<div class="well well-sm">没有数据！</div>');
                    return;
                }
                view_data_container.setTemplate('{#if $T.toomany}<div class="well well-sm" style="margin-bottom:9px;">搜索结果太多，仅显示最新发布前50条！</div>{#/if}<ul class="nav nav-tabs">{#foreach $T.list as record}<li><a href="#lang_{$T.record.id}" data-loadproduct="false" data-loaded="false" data-id="{$T.record.id}" data-toggle="tab">{$T.record.lang}</a></li>{#/for}<li><a href="#select_data_box" data-toggle="tab">已勾选(<span>0</span>)</a></li></ul><div class="tab-content">{#foreach $T.list as record}<div class="tab-pane" id="lang_{$T.record.id}"><ul class="list-unstyled">{#foreach $T.record.product as product}<li><div class="checkbox"><label><input type="checkbox" data-url="{$T.product.url}" value="{$T.product.id}" />{$T.product.name}</label> <span class="label label-primary getFileDetail" data-loaded="false" data-id="{$T.product.id}">详细信息</span></div></li>{#/for}</ul></div>{#/for}<div class="tab-pane" id="select_data_box"><pre>&#22768;&#26126;&#65306;&#26412;&#31449;&#36164;&#28304;&#22343;&#26469;&#33258;&#20110;&#23448;&#26041;&#21407;&#29256;&#65292;&#101;&#100;&#50;&#107;&#21487;&#35270;&#20026;&#80;&#50;&#80;&#19979;&#36733;&#38142;&#25509;&#12290;&#30001;&#20110;&#32593;&#32476;&#29615;&#22659;&#21644;&#19979;&#36733;&#24037;&#20855;&#30340;&#19981;&#30830;&#23450;&#24615;&#65292;&#26412;&#31449;&#19981;&#20445;&#35777;&#25152;&#26377;&#20154;&#37117;&#21487;&#20197;&#19979;&#36733;&#25104;&#21151;&#65292;&#22914;&#26524;&#22833;&#36133;&#21487;&#20197;&#26356;&#25442;&#32593;&#32476;&#25110;&#32773;&#19979;&#36733;&#24037;&#20855;&#37325;&#22797;&#23581;&#35797;&#12290;&#19979;&#36733;&#23436;&#25104;&#21518;&#21153;&#24517;&#36827;&#34892;&#83;&#72;&#65;&#49;&#26657;&#39564;&#65288;&#25512;&#33616;&#20351;&#29992;<a href="https://pan.baidu.com/s/1h_XvhgPJjq5E3n0fdbcXcA" target="_blank">iHasher</a>&#65289;&#65292;&#19982;&#32593;&#31449;&#26680;&#23545;&#19968;&#33268;&#21518;&#20877;&#20351;&#29992;&#12290;&#25152;&#26377;&#25805;&#20316;&#31995;&#32479;&#40664;&#35748;&#22343;&#20026;&#35797;&#29992;&#29256;&#65292;&#22914;&#26377;&#27491;&#29256;&#23494;&#38053;&#21487;&#20197;&#26377;&#25928;&#28608;&#27963;&#65292;&#26412;&#31449;&#19981;&#25552;&#20379;&#20219;&#20309;&#28608;&#27963;&#21644;&#30456;&#20851;&#26381;&#21153;&#12290;&#35831;&#22312;&#19979;&#36733;&#23436;&#25104;&#21518;&#20877;&#32771;&#34385;&#33258;&#24895;&#20026;&#26412;&#31449;&#25171;&#36175;&#25110;&#25424;&#21161;&#65292;&#19979;&#36733;&#36895;&#24230;&#19982;&#25424;&#21161;&#26080;&#20851;&#12290;&#22914;&#38656;&#36864;&#27454;&#35831;&#21457;&#37038;&#20214;&#33267;&#65306;&#109;&#64;&#105;&#116;&#101;&#108;&#108;&#121;&#111;&#117;&#46;&#99;&#110;&#65292;&#36864;&#27454;&#27809;&#26377;&#26377;&#25928;&#26399;&#65292;&#21482;&#38656;&#35201;&#25552;&#20379;&#20184;&#27454;&#25130;&#22270;&#21644;&#25910;&#27454;&#20108;&#32500;&#30721;&#21363;&#21487;&#65288;&#19981;&#26159;&#20108;&#32500;&#30721;&#21517;&#29255;&#65289;</pre></div></div>');
                view_data_container.processTemplate(data);
                first_tab_click();
            } else {
                view_data_container.html('<div class="alert alert-danger well-sm">' + response.message + '</div>');
            }
            $this.attr("data-loading", "false");
        });
        return false;
    });
    $('#search_form input').on("keydown", function () {
        if (event.keyCode === 13) {
            var form = $(this).parents("form:first");
            $('[type="submit"]', form).click();
            return false;
        }
    });
    $('#accordion').on('shown.bs.collapse', function (obj) {
        var $this = $(obj.target);
        var parent = $this.parents(".panel:first");
        var button = $('[data-loadmenu="true"]', parent);
        if (!button || button.length == 0)
            return;
        var id = button.data("menuid");
        var body = $(".panel-body", parent);
        $.post("/Category/Index", { id: id }, function (response) {
            body.setTemplate('<ul class="list-unstyled category ">{#foreach $T as record}<li data-id="{$T.record.id}" data-loaded="false" title="{$T.record.name}">{$T.record.name} <i class="fa fa-spinner fa-spin"></i></li>{#/for}</ul>');
            body.processTemplate(response);
            button.removeAttr('data-loadmenu');
        });
    })
    var display_data = function ($obj) {
        var data = $obj.data("load_detail");
        if (!data || data == undefined || data.length == 0) {
            view_data_container.html('<div class="well well-sm">没有数据！</div>');
            return;
        }
        view_data_container.setTemplate('<ul class="nav nav-tabs">{#foreach $T as record}<li><a href="#lang_{$T.record.id}" data-loadproduct="true" data-loaded="false" data-id="{$T.record.id}" data-toggle="tab">{$T.record.lang}</a></li>{#/for}<li><a href="#select_data_box" data-toggle="tab">已勾选(<span>0</span>)</a></li></ul><div class="tab-content">{#foreach $T as record}<div class="tab-pane" id="lang_{$T.record.id}"></div>{#/for}<div class="tab-pane" id="select_data_box"><pre>&#22768;&#26126;&#65306;&#26412;&#31449;&#36164;&#28304;&#22343;&#26469;&#33258;&#20110;&#23448;&#26041;&#21407;&#29256;&#65292;&#101;&#100;&#50;&#107;&#21487;&#35270;&#20026;&#80;&#50;&#80;&#19979;&#36733;&#38142;&#25509;&#12290;&#30001;&#20110;&#32593;&#32476;&#29615;&#22659;&#21644;&#19979;&#36733;&#24037;&#20855;&#30340;&#19981;&#30830;&#23450;&#24615;&#65292;&#26412;&#31449;&#19981;&#20445;&#35777;&#25152;&#26377;&#20154;&#37117;&#21487;&#20197;&#19979;&#36733;&#25104;&#21151;&#65292;&#22914;&#26524;&#22833;&#36133;&#21487;&#20197;&#26356;&#25442;&#32593;&#32476;&#25110;&#32773;&#19979;&#36733;&#24037;&#20855;&#37325;&#22797;&#23581;&#35797;&#12290;&#19979;&#36733;&#23436;&#25104;&#21518;&#21153;&#24517;&#36827;&#34892;&#83;&#72;&#65;&#49;&#26657;&#39564;&#65288;&#25512;&#33616;&#20351;&#29992;<a href="https://pan.baidu.com/s/1h_XvhgPJjq5E3n0fdbcXcA" target="_blank">iHasher</a>&#65289;&#65292;&#19982;&#32593;&#31449;&#26680;&#23545;&#19968;&#33268;&#21518;&#20877;&#20351;&#29992;&#12290;&#25152;&#26377;&#25805;&#20316;&#31995;&#32479;&#40664;&#35748;&#22343;&#20026;&#35797;&#29992;&#29256;&#65292;&#22914;&#26377;&#27491;&#29256;&#23494;&#38053;&#21487;&#20197;&#26377;&#25928;&#28608;&#27963;&#65292;&#26412;&#31449;&#19981;&#25552;&#20379;&#20219;&#20309;&#28608;&#27963;&#21644;&#30456;&#20851;&#26381;&#21153;&#12290;&#35831;&#22312;&#19979;&#36733;&#23436;&#25104;&#21518;&#20877;&#32771;&#34385;&#33258;&#24895;&#20026;&#26412;&#31449;&#25171;&#36175;&#25110;&#25424;&#21161;&#65292;&#19979;&#36733;&#36895;&#24230;&#19982;&#25424;&#21161;&#26080;&#20851;&#12290;&#22914;&#38656;&#36864;&#27454;&#35831;&#21457;&#37038;&#20214;&#33267;&#65306;&#109;&#64;&#105;&#116;&#101;&#108;&#108;&#121;&#111;&#117;&#46;&#99;&#110;&#65292;&#36864;&#27454;&#27809;&#26377;&#26377;&#25928;&#26399;&#65292;&#21482;&#38656;&#35201;&#25552;&#20379;&#20184;&#27454;&#25130;&#22270;&#21644;&#25910;&#27454;&#20108;&#32500;&#30721;&#21363;&#21487;&#65288;&#19981;&#26159;&#20108;&#32500;&#30721;&#21517;&#29255;&#65289;</pre></div></div>');
        view_data_container.processTemplate(data);
        first_tab_click();
    }
    $(document).on("click", ".category li", function () {
        var $this = $(this);
        if ($this.is(".active"))
            return;
        view_data_container.html('<i class="fa fa-spinner fa-spin"></i>');
        var parent = $this.parents("#accordion:first");
        $('li.active', parent).removeClass("active");
        $this.addClass("active");
        if ($this.attr('data-loaded') == 'true') {
            display_data($this);
            return;
        }
        if ($this.attr("data-loading") == "true")
            return;
        $this.attr("data-loading", "true");
        $.post("/Category/GetLang", { id: $this.data("id") }, function (response) {
            if (response.status) {
                $this.data("load_detail", response.result);
                display_data($this);
                $this.attr('data-loaded', 'true');
                $this.attr("data-loading", "false");
            }
        });
    });
    $(view_data_container).on("click", ".getFileDetail", function () {
        var $this = $(this);
        var parent = $this.parents("li:first");
        if ($this.attr('data-loaded') == 'true') {
            $("div.detail", parent).toggle();
            return;
        }
        var temp = $('div.detail', parent);
        if (!temp || temp.length == 0) {
            temp = $('<div class="detail"><i class="fa fa-spinner fa-spin"></i></div>');
            parent.append(temp);
        }
        if ($this.attr("data-loading") == "true")
            return;
        $this.attr("data-loading", "true");
        $.post("/Category/GetProduct", { id: $this.data("id") }, function (response) {
            if (response.status) {
                temp.setTemplate('<dl class="dl-horizontal"><dt>文件名</dt><dd>{$T.FileName}</dd><dt>SHA1</dt><dd>{$T.SHA1}</dd><dt>文件大小</dt><dd>{$T.size}</dd><dt>发布时间</dt><dd>{$T.PostDateString}</dd></dl><pre>{$T.DownLoad}</pre><pre>&#22768;&#26126;&#65306;&#26412;&#31449;&#36164;&#28304;&#22343;&#26469;&#33258;&#20110;&#23448;&#26041;&#21407;&#29256;&#65292;&#101;&#100;&#50;&#107;&#21487;&#35270;&#20026;&#80;&#50;&#80;&#19979;&#36733;&#38142;&#25509;&#12290;&#30001;&#20110;&#32593;&#32476;&#29615;&#22659;&#21644;&#19979;&#36733;&#24037;&#20855;&#30340;&#19981;&#30830;&#23450;&#24615;&#65292;&#26412;&#31449;&#19981;&#20445;&#35777;&#25152;&#26377;&#20154;&#37117;&#21487;&#20197;&#19979;&#36733;&#25104;&#21151;&#65292;&#22914;&#26524;&#22833;&#36133;&#21487;&#20197;&#26356;&#25442;&#32593;&#32476;&#25110;&#32773;&#19979;&#36733;&#24037;&#20855;&#37325;&#22797;&#23581;&#35797;&#12290;&#19979;&#36733;&#23436;&#25104;&#21518;&#21153;&#24517;&#36827;&#34892;&#83;&#72;&#65;&#49;&#26657;&#39564;&#65288;&#25512;&#33616;&#20351;&#29992;<a href="https://pan.baidu.com/s/1h_XvhgPJjq5E3n0fdbcXcA" target="_blank">iHasher</a>&#65289;&#65292;&#19982;&#32593;&#31449;&#26680;&#23545;&#19968;&#33268;&#21518;&#20877;&#20351;&#29992;&#12290;&#25152;&#26377;&#25805;&#20316;&#31995;&#32479;&#40664;&#35748;&#22343;&#20026;&#35797;&#29992;&#29256;&#65292;&#22914;&#26377;&#27491;&#29256;&#23494;&#38053;&#21487;&#20197;&#26377;&#25928;&#28608;&#27963;&#65292;&#26412;&#31449;&#19981;&#25552;&#20379;&#20219;&#20309;&#28608;&#27963;&#21644;&#30456;&#20851;&#26381;&#21153;&#12290;&#35831;&#22312;&#19979;&#36733;&#23436;&#25104;&#21518;&#20877;&#32771;&#34385;&#33258;&#24895;&#20026;&#26412;&#31449;&#25171;&#36175;&#25110;&#25424;&#21161;&#65292;&#19979;&#36733;&#36895;&#24230;&#19982;&#25424;&#21161;&#26080;&#20851;&#12290;&#22914;&#38656;&#36864;&#27454;&#35831;&#21457;&#37038;&#20214;&#33267;&#65306;&#109;&#64;&#105;&#116;&#101;&#108;&#108;&#121;&#111;&#117;&#46;&#99;&#110;&#65292;&#36864;&#27454;&#27809;&#26377;&#26377;&#25928;&#26399;&#65292;&#21482;&#38656;&#35201;&#25552;&#20379;&#20184;&#27454;&#25130;&#22270;&#21644;&#25910;&#27454;&#20108;&#32500;&#30721;&#21363;&#21487;&#65288;&#19981;&#26159;&#20108;&#32500;&#30721;&#21517;&#29255;&#65289;</pre><div class="shang_box"><div class="zhifubao"><img src="/images/345857188168186963.png"></div><div class="shang_pic"><img class="dashang xianshi" src="/images/shang.png"></div><div class="weixin"><img src="/images/563124707301432079.png"></div></div>');
                temp.processTemplate(response.result);
                $this.attr('data-loaded', 'true');
                $this.attr("data-loading", "false");
            };
        });
    });
    var check_select_data_box = function () {
        var select_data_box = $("#select_data_box pre.url", view_data_container);
        return select_data_box.length;
    }
    $(view_data_container).on("click", "input[type='checkbox']", function () {
        var $this = $(this);
        var id = $this.val();
        var url = $this.data('url');
        var select_data_box = $("#select_data_box", view_data_container);
        var selected = $('pre.url[id="url_' + id + '"]', select_data_box);
        if ($this.prop("checked")) {
            if (!selected || selected.length == 0) {
                select_data_box.append('<pre class="url" id="url_' + id + '">' + url + '</pre>');
            }
        } else {
            if (selected && selected.length > 0) {
                selected.remove();
            }
        };
        var check_count = check_select_data_box();
        $('a[href="#select_data_box"] span', view_data_container).text(check_count);
    });
});

